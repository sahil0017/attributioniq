# Urban Thread — sample data (1 November 2025–31 October 2026), synthetic

All timestamps without an explicit offset are UTC. Ad spend dates are UTC calendar days.
Files are an export taken at the end of the window: nothing received or sent after it is included.

- events.jsonl — one JSON event per line, as received by the tracking pixel, in order of arrival (received_at).
  Fields: event_id, event_name (page_view, identify, add_to_cart, checkout_started, purchase), ts (time on the
  visitor's device), received_at (time our server received it), anonymous_id (browser cookie), email_hash (present
  once the visitor has identified themselves, e.g. by logging in, signing up to the newsletter or checking out),
  page_url, referrer, user_agent, ip, and for cart/checkout/purchase: value, currency, order_id.
- orders.csv — order webhooks from the store's order system, one row per webhook, in the order they were sent
  (updated_at). An order gets a new webhook whenever it changes, so the same order_id can appear more than once.
  The order system is the source of truth for what was sold.
- ad_spend.csv — daily spend per campaign, pulled from the ad platforms (pulled_at = when it was pulled).
